module.exports = {
    mongoURI: 'mongodb+srv://admin:admin@nft-marketplace.stbi0.mongodb.net/nft-marketplace?retryWrites=true&w=majority',
    secretOrKey: 'SECRET'
}